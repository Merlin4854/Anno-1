using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D), typeof(TouchingDirection), typeof(Damageble))]
public class PlayerController : MonoBehaviour
{
    [SerializeField]
    private float speed = 6f;
    [SerializeField]
    private float airSpeed = 0.5f;
    [SerializeField]
    private float jumpImpulse = 7f;
    Vector2 moveinput;
    TouchingDirection touchingDirection;
    Damageble damageble;

    public float WallTouch 
    {
        get 
        {
            if (CanMove)
            {
                if (IsMoving && !touchingDirection.IsOnWall)
                {
                    if (touchingDirection.IsGrounded)
                    {
                        return speed;
                    }
                    else
                    {
                        // Air Move
                        return airSpeed;
                    }

                }
                else
                {
                    // 0 is Idle animation.
                    return 0;
                }
            }
            else
            {
                return 0;
            }

        }
    }

    [SerializeField]
    private bool _isMoving = false;

    public bool IsMoving 
    { 
        get
        {
            return _isMoving;
        }
        private set
        { 
            _isMoving = value;
            animator.SetBool(AnimationStrings.isMoving, value);
        } 
    }

    [SerializeField]
    private bool _isFacingRight = true;

    public bool IsFacingRight
    {
        get
        {
            return _isFacingRight;
        }
        private set
        {
            if (_isFacingRight != value) 
            {
                // Flipe the local scale to make the player face the opposit direction
                transform.localScale *= new Vector2(-1, 1);
            }

            _isFacingRight= value;
        }
    }

    Rigidbody2D rb;
    Animator animator;
    

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        touchingDirection = GetComponent<TouchingDirection>();
        damageble = GetComponent<Damageble>();
    }

    private void FixedUpdate()
    {
        if(!damageble.LockVelocity)
        {
            if (CanMove)
            {
                rb.velocity = new Vector2(moveinput.x * speed, rb.velocity.y);

                animator.SetFloat(AnimationStrings.yVelocity, rb.velocity.y);
            }
            else
            {
                rb.velocity = new Vector2(0, rb.velocity.y);
            }
        }

        
    }

    public void OnMove(InputAction.CallbackContext context)
    {
        moveinput = context.ReadValue<Vector2>();

        if(IsAlive)
        {
            IsMoving = moveinput != Vector2.zero;

            SetFacingDiretion(moveinput);
        }
        else
        {
            IsMoving= false;
        }
    }

    private void SetFacingDiretion(Vector2 moveinput)
    {
        if (moveinput.x > 0 && !IsFacingRight)
        {
            // Face the right
            IsFacingRight = true;
        }
        else if (moveinput.x < 0 && IsFacingRight)
        {
            // Face the left
            IsFacingRight= false;
        }
    }

    public bool CanMove
    {
        get
        {
            return animator.GetBool(AnimationStrings.canMove);
        }
    }

    public bool IsAlive
    {
        get
        {
            return animator.GetBool(AnimationStrings.isAlive);
        }
    }

    public void OnJump(InputAction.CallbackContext context) 
    {
        if (context.started && touchingDirection.IsGrounded && CanMove) 
        {
            animator.SetTrigger(AnimationStrings.jumpTrigger);
            rb.velocity = new Vector2(rb.velocity.x, jumpImpulse);
        }
    }

    public void OnAttack(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            animator.SetTrigger(AnimationStrings.attackTrigger);
        }
    }

    public void OnHit(int damage, Vector2 knokback)
    {
        rb.velocity = new Vector2(knokback.x, rb.velocity.y + knokback.y);
    }
}
