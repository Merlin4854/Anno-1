using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D), typeof(TouchingDirection), typeof(Damageble))]
public class Knight : MonoBehaviour
{
    [SerializeField]
    private float speed = 3f;
    [SerializeField]
    private float walkStopRate = 0.02f;
    public DetectionZone attackZone;
    public DetectionZone cliffDetectionZone;

    Rigidbody2D rb;
    Animator animator;
    TouchingDirection touchingDirection;
    Damageble damageble;

    public enum WalkableDirection {right, left};
    private WalkableDirection _walkDirection;
    private Vector2 walkDirectionVector = Vector2.right;

    public WalkableDirection WalkDirection 
    {
        get { return _walkDirection; }
        set 
        { 
            if (_walkDirection != value) 
            {
                // Direction Flip
                gameObject.transform.localScale = new Vector2(gameObject.transform.localScale.x * -1, gameObject.transform.localScale.y);
                
                if (value == WalkableDirection.right) 
                {
                    walkDirectionVector = Vector2.right;
                }
                else if (value == WalkableDirection.left)
                {
                    walkDirectionVector = Vector2.left;
                }
            }
            _walkDirection = value; 
        }
    }

    public bool _hasTarget = false;
    public bool HasTarget 
    { 
        get 
        {
            return _hasTarget;
        }
        private set
        {
            _hasTarget = value;
            animator.SetBool(AnimationStrings.hasTaret, value);
        }
    }

    public bool CanMove 
    { 
        get
        {
            return animator.GetBool(AnimationStrings.canMove);
        } 
    }

    public float AttackCoulDown 
    {
        get
        {
            return animator.GetFloat(AnimationStrings.attackCoulDown);
        }
        private set
        {
            animator.SetFloat(AnimationStrings.attackCoulDown, Mathf.Max(value, 0));
        }
    }

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        touchingDirection = GetComponent<TouchingDirection>();
        damageble = GetComponent<Damageble>();
    }

    public void Update()
    {
        HasTarget = attackZone.detectedColliders.Count > 0;

        if (AttackCoulDown > 0)
        {
            AttackCoulDown -= Time.deltaTime;
        }       
    }

    public void FixedUpdate()
    {
        if (touchingDirection.IsGrounded && touchingDirection.IsOnWall) 
        {
            FlipDirection();
        }
        if(!damageble.LockVelocity)
        {
            if (CanMove)
            {
                rb.velocity = new Vector2(speed * walkDirectionVector.x, rb.velocity.y);
            }
            else
            {
                rb.velocity = new Vector2(Mathf.Lerp(rb.velocity.x, 0, walkStopRate), rb.velocity.y);
            }
        } 
    }

    private void FlipDirection()
    {
        if (WalkDirection == WalkableDirection.right) 
        {
            WalkDirection = WalkableDirection.left;
        }
        else if (WalkDirection == WalkableDirection.left)
        {
            WalkDirection = WalkableDirection.right;
        }
        else
        {
            Debug.LogError("Current WalkableDirection is not set to legal value of right or left");
        }
    }

    public void OnHit(int damage, Vector2 knokback)
    {
        rb.velocity = new Vector2(knokback.x, rb.velocity.y + knokback.y);
    }

public void OnCliffDetected()
    {
        if(touchingDirection.IsGrounded)
        {
            FlipDirection();
        }
    }
}
